#include "Config.h"
#include "Logger.h"
#include "DeviceInfo.h"

unsigned long lastHeartbeat = 0;

// void setup()
// {
//     Logger::begin();

//     Logger::info("Boot Complete");

//     DeviceInfo device;

// device.deviceName = DEVICE_NAME;

// device.firmwareVersion = FIRMWARE_VERSION;

// device.chipModel = ESP.getChipModel();

// device.status = "READY";

// device.personCount = 0;

// device.petCount = 0;

// device.freeHeap = ESP.getFreeHeap();

// device.uptime = 0;

// Logger::info("Device Model Created");
// }

void setup()
{
    Logger::begin();

    delay(2000);

    Logger::info("111111111111");

    delay(1000);

    Logger::info("222222222222");

    delay(1000);

    Logger::info("333333333333");

    delay(1000);

    Logger::info("444444444444");
}

void loop()
{
    // if (millis() - lastHeartbeat >= HEARTBEAT_INTERVAL)
    // {
    //     lastHeartbeat = millis();

    //     Logger::info(
    //         "Free Heap : " + String(ESP.getFreeHeap())
    //     );
    // }
}